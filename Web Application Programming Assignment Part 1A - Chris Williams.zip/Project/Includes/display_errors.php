<?php

    ini_set('display errors', 1); //For development only, needs to be toggled for final usage

?>