<?php 
    // This file is the main window content for the site, from where all functions are accessible.
    
    // DB Functions / session import here 

    require "./Includes/header.php";
    header("Location: profile.php");
?>


    
           

<?php 
    // Import Footer
    require "./Includes/footer.php"
?>